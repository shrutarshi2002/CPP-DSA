# Aug 5
## Mathematics

1.<a href="https://practice.geeksforgeeks.org/problems/missing-number-in-array1416/1"> missing umber in array </a><br>
2.<a href="https://practice.geeksforgeeks.org/problems/minimum-steps-to-make-product-equal-to-one/1/">minimum-steps-to-make-product-equal-to-one</a><br>
3.<a href="https://practice.geeksforgeeks.org/problems/trailing-zeroes-in-factorial5134/1">trailing-zeroes-in-factorial</a><br>
4.<a href="https://practice.geeksforgeeks.org/problems/a-simple-fraction0921/1">a-simple-fraction</a><br>
5.<a href="https://practice.geeksforgeeks.org/problems/count-of-sum-of-consecutives3741/1">Count of sum of consecutives</a><br>
6.<a href="https://practice.geeksforgeeks.org/problems/ncr1019/1/?difficulty[]=1&page=1&category[]=Mathematical&query=difficulty[]1page1category[]Mathematical">nCr</a><br>

1. <a href="https://practice.geeksforgeeks.org/problems/digits-in-factorial/1/">digits-in-factorial</a>
2. <a href="https://practice.geeksforgeeks.org/problems/gp-term/1">gp-term</a>
3. <a href="https://practice.geeksforgeeks.org/problems/primality-test/1/">primality-test</a><br>
4. <a href="https://practice.geeksforgeeks.org/problems/exactly-3-divisors/1/">exactly-3-divisors</a>
5. <a href="https://practice.geeksforgeeks.org/problems/modular-multiplicative-inverse-1587115620/1/">modular-multiplicative-inverse</a>



1. <a href="https://practice.geeksforgeeks.org/problems/smallest-divisible-number/1">smallest-divisible-number</a>
2. <a href="https://practice.geeksforgeeks.org/problems/addition-under-modulo/1">addition-under-modulo</a>
3. <a href="https://practice.geeksforgeeks.org/problems/absolute-value/1/">absolute-value</a><br>
4. <a href="https://practice.geeksforgeeks.org/problems/convert-celsius-to-fahrenheit/1">convert-celsius-to-fahrenheit</a>
5. <a href="https://practice.geeksforgeeks.org/problems/quadratic-equation-roots/1">quadratic-equation-roots</a>
6. <a href="https://www.codechef.com/problems/BILLRD/">Point Of Impact</a>